## Telresender
Just resend your messages.

## Install
 1. Install telebot module: `sudo pip install pytelegrambotapi`
 2. In `config.py` write your token from `@FatherBot` (so easy) and owner chatId.
 3. Run: `python bot.py &`

## License
"telresender" is licensed under the [MIT License](https://github.com/bixnel/telresender/blob/master/LICENSE).
